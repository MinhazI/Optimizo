# Optimizo

Optimizo is a WordPress plugin that will automatically optimize your website to reduce the page load time (PLT) for your website. It will include many optimizations, like adding GZip compression and caching via .htaccess and also it will include minification of HTML, CSS and JavaScript which in return would help the PLT of your website.
