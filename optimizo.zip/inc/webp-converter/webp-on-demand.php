<?php

global $cacheDir;

require __DIR__ .'/webp-on-demand.inc';

use WebPOnDemand\WebPOnDemand;

$imageSource = $_GET['source'];            // Absolute file path to source file. Comes from the .htaccess
$destinationDir = $cacheDir . '/webp-images/';

if (! is_dir($destinationDir)){
	@mkdir($destinationDir, 0755, true);
}

$newImageSource = strstr($imageSource, 'uploads');

$imageDestination = $destinationDir . '/' . $newImageSource . '.webp';

$options = [

	// Tell where to find the webp-convert-and-serve library, which will
	// be dynamically loaded, if need be.
	'require-for-conversion' => __DIR__ . '/webp-convert-and-serve.inc',
	'max-quality' => 80,
	'quality' => 80,
	'fail'                 => 'original',     // ('original' | 404' | 'throw' | 'report')
	'fail-when-fail-fails' => 'throw',        // ('original' | 404' | 'throw' | 'report')
	'preferred-converters' => ['cwebp', 'gd']


	// More options available!
];

WebPOnDemand::serve($imageSource, $imageDestination, $options);